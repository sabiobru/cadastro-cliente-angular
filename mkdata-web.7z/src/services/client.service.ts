import { Observable } from 'rxjs';
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class ClientService {
  private url = 'https://localhost:8081/client';

  constructor(
    private http: HttpClient
  ) { }

  findByidentityDocument(identityDocument: string) {
    return this.http.post(this.url, identityDocument);
  }

  createClient(client: string) {
    return this.http.post(this.url, client);
  }

}
